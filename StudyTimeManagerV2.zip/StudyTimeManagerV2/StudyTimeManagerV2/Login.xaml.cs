﻿using StudyTimeManagerV2.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace StudyTimeManagerV2
{
    /// <summary>
    /// Interaction logic for Login.xaml
    /// </summary>
    public partial class Login : Window
    {
        public Login(string username)
        {
            InitializeComponent();
            tbUsername.Text = username;  // add username entered when registering by default
        }

        // model folder -> global instantiation
        Student stud = new Student();
        DatabaseContext databaseContext = new DatabaseContext();

        private void Button_Click(object sender, RoutedEventArgs e) // navigate to home page
        {
            MainWindow mw = new MainWindow();
            mw.Show();
            this.Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e) // login
        {
            try
            {
                // store user input
                stud.username = tbUsername.Text;
                string password = tbPassword.Text;

                // call Encrpt method to hash password
                stud.passwordHashed = Encrypt(password);

                // linq query to check if username and password
                var logincheck = (from b in databaseContext.Students
                                  where b.username == stud.username && b.passwordHashed == stud.passwordHashed
                                  select b).Any();

                // linq query used
                if (logincheck.ToString() == "True")
                {
                    addSemester s = new addSemester(stud.username);  
                    s.Show();  // navigate to addSemester page
                    this.Close();
                }
                else
                {
                    // error message
                    MessageBox.Show("Login details are incorrect. Please re-enter Username and Password.");
                    tbPassword.Clear();
                }
            }
            catch (Exception)
            {
                // error message
                MessageBox.Show("Please re-enter Login details.");
                tbUsername.Clear();
                tbPassword.Clear();
            }
        }

        public string Encrypt(string value)  // used for hashing
        {
            // using MDS to encrpyt a string
            using (MD5CryptoServiceProvider md5 = new MD5CryptoServiceProvider())
            {
                UTF8Encoding utf8 = new UTF8Encoding();
                // hash data
                byte[] data = md5.ComputeHash(utf8.GetBytes(value));
                return Convert.ToBase64String(data);
            }
        }
    }
}
