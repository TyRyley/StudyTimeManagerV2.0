﻿using StudyTimeManagerV2.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Xml.Linq;

namespace StudyTimeManagerV2
{
    /// <summary>
    /// Interaction logic for hoursWorked.xaml
    /// </summary>
    public partial class hoursWorked : Window
    {
        public hoursWorked(string username)
        {
            InitializeComponent();
            lblSuccessful.Visibility = Visibility.Hidden;
            m.username = username;
            // method called to add module names to combo box
            addModulesCbx();
            gridwork.Visibility = Visibility.Hidden;
        }

        // model folder -> global instantiation
        Module m = new Module();
        DatabaseContext databaseContext = new DatabaseContext();

        // method to add module names to combo box
        public void addModulesCbx()
        {
            // lambda used to retrieve semester names from user that is currently logged in
            var additman = databaseContext.Modules.Where(Module => Module.username == m.username);
            foreach (Module b in additman)
            {
                // add module names to combo box
                cbxModule.Items.Add(b.name);
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)  // submit button
        {
            try
            {
                if (cbxModule.Text.Length == 0 || tbHours.Text.Length == 0 || dpDate.Text.Length == 0)
                {
                    MessageBox.Show("Please fill in all fields.");
                }
                else
                {
                    // store user input
                    m.name = cbxModule.Text;
                    int hours = Convert.ToInt32(tbHours.Text);
                    DateTime dateWorked = Convert.ToDateTime(dpDate.SelectedDate);

                    // lambda used to work with module info from user that is currently logged in
                    var subtractHours = databaseContext.Modules.Where(Module => Module.username == m.username);
                    foreach (Module b in subtractHours)
                    {
                        // match module name in database with user input
                        if (b.name == m.name)
                        {
                            // subtract hours that user entered from initial remaining hours
                            b.remaininghours = b.remaininghours - hours;
                            lblSuccessful.Visibility = Visibility.Hidden;
                            // populate grid
                            tbFinalName.Text = m.name;
                            tbFinalHours.Text = Convert.ToString(hours);
                            tbFinalDate.Text = dateWorked.Date.ToString();
                            // enable grid
                            gridwork.Visibility = Visibility.Visible;

                        }
                    }
                    // save changes made to database
                    databaseContext.SaveChanges();
                    // refresh datagridview
                    bindGrid();
                }
            }
            catch (Exception)
            {
                // error message
                MessageBox.Show("Please enter a number for number of hours.");
            }

        }

        private void Button_Click_1(object sender, RoutedEventArgs e) // close application
        {
            this.Close();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)  // navigate back to addModule
        {
            addModule am = new addModule(m.username);
            am.Show();
            this.Close();
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)  // navigate back to home page
        {
            MainWindow mw = new MainWindow();
            mw.Show();
            this.Close();
        }

        private void Button_Click_4(object sender, RoutedEventArgs e)  // clear user input
        {
            cbxModule.Text = "";
            tbHours.Clear();
            dpDate.Text = "Select a date";
            tbFinalDate.Clear();
            tbFinalHours.Clear();
            tbFinalName.Clear();
        }

        private void Button_Click_5(object sender, RoutedEventArgs e)  // view
        {
            // call method to popullate datagridview
            bindGrid();
        }

        public void bindGrid()
        {
            // linq query for user to view their own modules
            var specific = from b in databaseContext.Modules
                           where b.username == m.username
                           select b;
            datagridmodule.ItemsSource = specific.ToList();
        }
    }
}
