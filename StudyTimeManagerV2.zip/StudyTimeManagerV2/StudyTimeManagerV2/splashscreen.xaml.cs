﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace StudyTimeManagerV2
{
    /// <summary>
    /// Interaction logic for splashscreen.xaml
    /// </summary>
    public partial class splashscreen : Window
    {
        // create object used for splash to get to next window
        DispatcherTimer dt = new DispatcherTimer();
        public splashscreen()
        {
            InitializeComponent();

            // call timer for splash
            dt.Tick += new EventHandler(dt_Tick);
            dt.Interval = new TimeSpan(0, 0, 3);  // 0 days, 0 hours, 3 seconds
            dt.Start();  // start timer
        }

        private void dt_Tick(object sender, EventArgs e)
        {
            MainWindow mw = new MainWindow();  // create object of next window to navigate to it
            mw.Show();  // open next window
            dt.Stop(); // stop timer
            this.Close();  // close current window
        }
    }
}
