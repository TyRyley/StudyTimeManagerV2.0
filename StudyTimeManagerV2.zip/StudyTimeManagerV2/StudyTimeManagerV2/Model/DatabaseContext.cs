﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudyTimeManagerV2.Model
{
    internal class DatabaseContext : DbContext
    {
        public DbSet<Student> Students { get; set; }
        public DbSet<Semester> Semesters { get; set; }
        public DbSet<Module> Modules { get; set; }
    }
}
