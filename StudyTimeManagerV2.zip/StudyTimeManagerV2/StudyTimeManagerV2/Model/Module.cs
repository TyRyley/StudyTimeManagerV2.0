﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudyTimeManagerV2.Model
{
    internal class Module
    {
        [Key]
        public int Id { get; set; }
        public string code { get; set; }
        public string name { get; set; }
        public int noOfCredits { get; set; }
        public int classHoursPerWeek { get; set; }
        public int remaininghours { get; set; }
        public double selfStudyHours { get; set; }
        public string semesterID { get; set; }
        public string username { get; set; }
    }
}
