﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudyTimeManagerV2.Model
{
    internal class Student
    {
        [Key]
        public string username { get; set; }
        public string passwordHashed { get; set; }
    }
}
