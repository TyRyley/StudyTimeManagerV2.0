﻿using StudyTimeManagerV2.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace StudyTimeManagerV2
{
    /// <summary>
    /// Interaction logic for addSemester.xaml
    /// </summary>
    public partial class addSemester : Window
    {
        public addSemester(string username)
        {
            InitializeComponent();
            // welcome user message
            lblWelcome.Content = "Welcome " + username + "!";
            s.username = username;
            lblSuccessfullyAdded.Visibility = Visibility.Hidden;
        }


        // model folder -> global instantiation
        Semester s = new Semester();
        DatabaseContext databaseContext = new DatabaseContext();


        private void dataGridSemester_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void Button_Click(object sender, RoutedEventArgs e)  // view semesters
        {
            bindGrid();
        }

        // method to bind gridview
        public void bindGrid()
        {
            // linq query for user to view their own semesters
            var specific = from b in databaseContext.Semesters
                           where b.username == s.username
                           select b;
            dataGridSemester.ItemsSource = specific.ToList();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)  // add semester
        {
            try
            {
                if (tbName.Text.Length == 0 || tbNoOfWeeks.Text.Length == 0 || dpDate.Text.Length == 0)
                {
                    MessageBox.Show("Please fill in all fields.");
                }
                else
                {
                    // store user input
                    s.semesterID = tbName.Text;
                    s.noOfWeeks = Convert.ToInt32(tbNoOfWeeks.Text);
                    s.startDate = Convert.ToDateTime(dpDate.SelectedDate);

                    // add semester info to database
                    databaseContext.Semesters.Add(s);
                    // save changes to database
                    databaseContext.SaveChanges();
                    // enable semester successfully added label
                    lblSuccessfullyAdded.Visibility = Visibility.Visible;
                    // refresh the datagridview
                    bindGrid();
                }
            }
            catch (Exception)
            {
                // error message
                MessageBox.Show("Please enter a number for Number of weeks.");
            }
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)  // clear user input
        {
            tbName.Clear();
            tbNoOfWeeks.Clear();
            dpDate.Text = "Select a date";
        }

        private void btnAddModules_Click(object sender, RoutedEventArgs e)  // navigate to addModule
        {
            addModule am = new addModule(s.username);
            am.Show();
            this.Close();
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)  // navigate back to home page
        {
            MainWindow mw = new MainWindow();
            mw.Show();
            this.Close();
        }
    }
}
