﻿using StudyTimeManagerV2.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace StudyTimeManagerV2
{
    /// <summary>
    /// Interaction logic for Register.xaml
    /// </summary>
    public partial class Register : Window
    {
        public Register()
        {
            InitializeComponent();
        }

        // model folder -> global instantiation
        Student stud = new Student();
        DatabaseContext databaseContext = new DatabaseContext();


        private void Button_Click(object sender, RoutedEventArgs e) // back
        {
            MainWindow mw = new MainWindow();
            mw.Show();
            this.Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e) // register
        {
            try
            {
                // store user input
                stud.username = tbUsername.Text;
                string password = tbPassword.Text;
                string confirmPassword = tbConfirmPassword.Text;

                // check if passwords match
                if (password != confirmPassword)
                {
                    MessageBox.Show("Passwords do not match. Please re-enter passwords.");
                }
                else
                {
                    stud.passwordHashed = Encrypt(tbConfirmPassword.Text);  // call method to hash password
                    databaseContext.Students.Add(stud);  // add student info to database
                    databaseContext.SaveChanges();  // save changes to database
                    MessageBox.Show("You have successfully registered " + stud.username + ". You may now Login.");
                    Login l = new Login(stud.username);
                    l.Show();
                    this.Close();
                }
            }
            catch (Exception)
            {
                // error message
                MessageBox.Show("Username is taken. Please enter a different Username.");
            }
            
        }

        public string Encrypt(string value)  // used for hashing
        {
            // using MDS to encrpyt a string
            using (MD5CryptoServiceProvider md5 = new MD5CryptoServiceProvider())
            {
                UTF8Encoding utf8 = new UTF8Encoding();
                // hash data
                byte[] data = md5.ComputeHash(utf8.GetBytes(value));
                return Convert.ToBase64String(data);
            }
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)  // clear textboxes
        {
            tbUsername.Clear();
            tbPassword.Clear();
            tbConfirmPassword.Clear();
        }
    }
}
