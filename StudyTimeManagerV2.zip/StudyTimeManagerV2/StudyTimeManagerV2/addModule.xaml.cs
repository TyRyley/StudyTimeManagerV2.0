﻿using StudyTimeManagerV2.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ClassLibraryStudy;

namespace StudyTimeManagerV2
{
    /// <summary>
    /// Interaction logic for addModule.xaml
    /// </summary>
    public partial class addModule : Window
    {
        public addModule(string username)
        {
            InitializeComponent();
            // welcome user message
            lblWelcome.Content = "Welcome " + username + "!";
            m.username = username;
            lblSuccessfullyAdded.Visibility = Visibility.Hidden;
            // method to add semesters to comobo box
            addSemestersCbx();
        }


        // model folder -> global instantiation
        Module m = new Module();
        Semester s = new Semester();
        DatabaseContext databaseContext = new DatabaseContext();

        private void Button_Click(object sender, RoutedEventArgs e)  // view modules
        {
            // method called to populate datagridview
            bindGrid();
        }

        // method to add semesters to combo box
        public void addSemestersCbx()
        {
            // lambda used to retrieve semester names from user that is currently logged in
            var additman = databaseContext.Semesters.Where(Semester => Semester.username == m.username);
            foreach (Semester b in additman)
            {
                // add semester names to combo box
                cbxSemester.Items.Add(b.semesterID);
            }
        }

        // method to bind gridview
        public void bindGrid()
        {
            // linq query for user to view their own modules
            var specific = from b in databaseContext.Modules
                           where b.username == m.username && b.semesterID == cbxSemester.Text
                           select b;
            dataGridModule.ItemsSource = specific.ToList();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)  // clear user input
        {
            tbName.Clear();
            tbName.Clear();
            tbCredits.Clear();
            tbClassHours.Clear();
            cbxSemester.Text = "";
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)  // add module
        {
            try
            {
                if (tbCode.Text.Length == 0 || tbName.Text.Length == 0 || tbCredits.Text.Length == 0 || tbClassHours.Text.Length == 0 || cbxSemester.Text.Length == 0)
                {
                    MessageBox.Show("Please fill in all fields.");
                }
                else
                {
                    // store user input
                    m.code = tbCode.Text;
                    m.name = tbName.Text;
                    m.noOfCredits = Convert.ToInt32(tbCredits.Text);
                    m.classHoursPerWeek = Convert.ToInt32(tbClassHours.Text);
                    m.semesterID = cbxSemester.Text;

                    int week=0;
                    // lambda used to retrieve semester week from semester of user that is currently logged in
                    var getWeek = databaseContext.Semesters.Where(Semester => Semester.username == m.username);
                    foreach (Semester b in getWeek)
                    {
                        // if the semester is the same as the one chosen, then use that number of weeks in calculation
                        if (b.semesterID == m.semesterID)
                        {
                            week = b.noOfWeeks;
                        }
                    }

                    // dll used to calculate self study hours per week
                    m.selfStudyHours = ClassLibraryStudy.Class1.calc(m.noOfCredits, week, m.classHoursPerWeek);
                    // remaining hours = self studty hours per week * no of weeks
                    m.remaininghours = Convert.ToInt32(m.selfStudyHours) * week;


                    // add module info to database
                    databaseContext.Modules.Add(m);
                    // save changes to database
                    databaseContext.SaveChanges();
                    // enable successfuly added module label
                    lblSuccessfullyAdded.Visibility = Visibility.Visible;
                    // refresh datagridview
                    bindGrid();
                }
            }
            catch (Exception)
            {
                // error message
                MessageBox.Show("Please enter numbers for Credits and Class Hours per week.");
            }
            
        }

        private void btnHours_Click(object sender, RoutedEventArgs e)  // navigate to hoursWorked
        {
            hoursWorked hw = new hoursWorked(m.username);
            hw.Show();
            this.Close();
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)  // navigate back to home page
        {
            MainWindow mw = new MainWindow();
            mw.Show();
            this.Close();
        }

        private void Button_Click_4(object sender, RoutedEventArgs e)  // navigate back to addSemester page
        {
            addSemester s = new addSemester(m.username);
            s.Show();
            this.Close();
        }
    }
}
